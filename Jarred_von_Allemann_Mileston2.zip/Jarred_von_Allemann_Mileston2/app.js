require('dotenv').config() //makes use of .env file and its config values (process.env.value)

const express = require('express') //buildng the webserver.
const appServer = express(); //this is our "entire application"

const port = process.env.port; //port value collected from .env file - process = global variable to application
const host = process.env.host; //host value collected from .env file - process = global variable to application

appServer.set('views', './views');
appServer.set('view engine', 'ejs') //setting the view engine to "ejs" (needed for app to work) - also, no need to require() it first.
appServer.use(express.static('public')) //make the entire app access/make requests to this folder

//Routes for ports
appServer.get('/', function(req,res)
{
    res.render('index.ejs')
})

appServer.listen(port, host, function()
{console.log(`Server is running on port ${port} and on server: ${host}`);})

